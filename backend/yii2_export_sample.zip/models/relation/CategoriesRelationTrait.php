<?php

namespace xbsoft\blog\models\relation;


/**
 * Trait CategoriesRelationTrait
 * @package xbsoft\blog\models\relation
 */
trait CategoriesRelationTrait
{
} 