<?php

namespace xbsoft\blog\models\relation;


/**
 * Trait UsersRelationTrait
 * @package xbsoft\blog\models\relation
 */
trait UsersRelationTrait
{
} 